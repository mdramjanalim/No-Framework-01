// --- পার্ট ১: PNG থেকে JPG কনভার্টার ---

function convertPngToJpg() {
    // ইনপুট এবং ডাউনলোড লিংক বাটন ধরা
    const input = document.getElementById('pngInput');
    const downloadLink = document.getElementById('jpgDownload');

    // চেক করা হচ্ছে ফাইল সিলেক্ট করা হয়েছে কিনা
    if (input.files && input.files[0]) {
        const reader = new FileReader();

        reader.onload = function(e) {
            const img = new Image();
            img.onload = function() {
                // ক্যানভাস তৈরি করা (এটি ব্রাউজারের একটি ড্রয়িং টুল)
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext('2d');

                // ব্যাকগ্রাউন্ড সাদা করা (কারণ PNG ট্রান্সপারেন্ট হতে পারে, কিন্তু JPG কালো হয়ে যায়)
                ctx.fillStyle = "#FFFFFF";
                ctx.fillRect(0, 0, canvas.width, canvas.height);

                // ক্যানভাসে ছবি আঁকা
                ctx.drawImage(img, 0, 0);

                // ছবিকে JPG ফরম্যাটে রূপান্তর করা (0.9 মানে ৯০% কোয়ালিটি)
                const dataUrl = canvas.toDataURL('image/jpeg', 0.9);

                // ডাউনলোড লিংক তৈরি করা
                downloadLink.href = dataUrl;
                downloadLink.download = 'converted-image.jpg';
                downloadLink.style.display = 'block'; // লিংক দৃশ্যমান করা
                downloadLink.textContent = "ডাউনলোড করুন (JPG)";
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        alert("দয়া করে প্রথমে একটি PNG ছবি সিলেক্ট করুন!");
    }
}

// --- পার্ট ২: JPG থেকে PDF কনভার্টার ---

async function convertJpgToPdf() {
    // jsPDF লাইব্রেরি লোড করা
    const { jsPDF } = window.jspdf;
    const input = document.getElementById('jpgInput');

    if (input.files && input.files[0]) {
        const reader = new FileReader();

        reader.onload = function(e) {
            const img = new Image();
            img.onload = function() {
                // ছবির সাইজ অনুযায়ী PDF এর ওরিয়েন্টেশন (খাড়া বা শোয়ানো) ঠিক করা
                const orientation = img.width > img.height ? 'l' : 'p';
                
                // PDF ডকুমেন্ট তৈরি
                const doc = new jsPDF({
                    orientation: orientation,
                    unit: 'px',
                    format: [img.width, img.height]
                });

                // PDF এর ভেতরে ছবি বসানো
                doc.addImage(img, 'JPEG', 0, 0, img.width, img.height);
                
                // ফাইল সেভ করা
                doc.save('converted-document.pdf');
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        alert("দয়া করে প্রথমে একটি JPG ছবি সিলেক্ট করুন!");
    }
}
